package com.example;

public class Bar {
    public int compute(int input) {
        int result = input;

        // filler lines for mutation context
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;

        // around line 42
        result = result + 2;

        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;
        result += 1;

        // around line 55
        if (result > 10) {
            result = result - 1;
        }

        return result;
    }
}
